<?php

/**
 * Created by PhpStorm.
 * User: Florian
 * Date: 17.10.2015
 * Time: 13:37
 */
class SeacceleratorTest extends PHPUnit_Framework_TestCase {

}
