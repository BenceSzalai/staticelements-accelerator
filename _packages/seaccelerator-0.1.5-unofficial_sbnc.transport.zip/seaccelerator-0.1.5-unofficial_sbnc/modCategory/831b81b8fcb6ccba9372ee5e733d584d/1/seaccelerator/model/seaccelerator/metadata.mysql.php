<?php
/**
 * This file is required to avoid ModX Warning being logged:
 * "Could not load package metadata for package seaccelerator"
 */

$xpdo_meta_map = [
	//none
];
