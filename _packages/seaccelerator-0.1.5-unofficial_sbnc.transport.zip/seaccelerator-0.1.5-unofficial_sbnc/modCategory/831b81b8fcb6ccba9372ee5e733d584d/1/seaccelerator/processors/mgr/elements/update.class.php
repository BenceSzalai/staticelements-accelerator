<?php
/**
 * @package Seaccelerator
 * @subpackage processors
 */
class SeacceleratorUpdateProcessor extends modObjectUpdateProcessor {

  public $classKey = 'Seaccelerator';
  public $languageTopics = array('seaccelerator:default');

}

return 'SeacceleratorUpdateProcessor';
